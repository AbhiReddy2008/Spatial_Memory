package com.example.spatialmemory

class ocrreader {
}
